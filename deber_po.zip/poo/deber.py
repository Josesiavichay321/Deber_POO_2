import datetime

class Tienda:
    def _init_(self, id, descripcion):
        self.id=id
        self.descripc=descripcion
        def _str_(self):
            return f"{self.id}-{self.descripcion}"
class Tipo:
    def _init_(self, id, tipo):
        self.id = id
        self.tipo = tipo
    def _str_(self):
        return f"{self.id} {self.tipo}"

class Producto:
    def _init_(self, id, cant_actual, cant_min, precio, tipo):
        self.id=id
        self.producto = []
        self.cant= cant_actual
        self.cant_m= cant_min
        self.precio= precio
        self.tipo= tipo
    def agregar(self, nomProducto):
        if nomProducto:
            self.producto.append(nomProducto)
            print(self.producto)
        else:
            print("Es obligatorio ingresar información")
    def abastecer(self, nomProducto, cantProducto):
        if nomProducto in self.producto:
            self.cant += cantProducto
            return f"{self.id} {self.cant}"
        else:
            print("El producto no existe, favor agregarlo para poder ser abastecido")   
    def mostrar(self):
        for i in self.producto:
            return f"{self.id} {i} {self.cant}"

class DetalleVenta:
    def _init_(self, id, cant, precio, subtotal, iva, total):
        self.id = id
        self.cant = cant
        self.precio = precio
        self.subtotal = subtotal
        self.iva = iva
        self.total = total
        self.producto = []

class Venta:
    def _init_(self, id, email, observacion):
        self.id = id
        self.fecha = datetime.datetime.now()
        self.email = email
        self.observacion = observacion
    def obtenerProducto(self, id, cant_actual, cant_min, precio, tipo):
        produ = Producto(id, cant_actual, cant_min, precio, tipo)
        if produ:
            for i in produ.producto:
                print(i)
        else:  
            pass
    def agregar(self, id, cant, precio, subtotal, iva, total):
        det = DetalleVenta(id, cant, precio, subtotal, iva, total)
        det.producto.append(det)
    def mostrar(self):
        pass


        
        
